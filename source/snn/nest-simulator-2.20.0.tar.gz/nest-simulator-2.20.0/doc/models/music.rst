MUSIC related devices
================================

.. doxygengroup:: music
   :content-only:
