Gap junction model
===============================

.. doxygengroup:: gap
   :content-only:
