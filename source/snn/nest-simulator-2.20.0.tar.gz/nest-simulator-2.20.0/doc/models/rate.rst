Rate-based neuron models
================================

.. doxygengroup:: rate
   :content-only:
