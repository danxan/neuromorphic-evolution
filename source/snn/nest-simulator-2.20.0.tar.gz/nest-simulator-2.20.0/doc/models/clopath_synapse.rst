Clopath synapse models
=======================

.. doxygengroup:: clopath_s
   :content-only:
