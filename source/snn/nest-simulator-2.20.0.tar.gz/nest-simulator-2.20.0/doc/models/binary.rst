Binary neuron model
================================

.. doxygengroup:: binary
   :content-only:
