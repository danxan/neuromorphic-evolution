Static synapse models
=======================

.. doxygengroup:: static
   :content-only:
