Instananeous rate synapse models
=======================================================

.. doxygengroup:: inst_rate
   :content-only:
