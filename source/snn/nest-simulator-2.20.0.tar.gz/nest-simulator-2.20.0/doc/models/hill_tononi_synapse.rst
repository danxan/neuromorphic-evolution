Hill-Tononi synapse model
==============================

.. doxygengroup:: ht_synapse
   :content-only:
