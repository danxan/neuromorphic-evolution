Spike-timing dependent plasticity (STDP) synapse models
========================================================

.. doxygengroup:: stdp
   :content-only:
