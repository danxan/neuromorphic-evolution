Short-term plasticity (STP) synapse models
=======================================================

.. doxygengroup:: stp
   :content-only:

