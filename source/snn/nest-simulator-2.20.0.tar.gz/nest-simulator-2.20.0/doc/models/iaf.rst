Integrate-and-Fire (IF) neuron models
==================================================

This category contains all `iaf`, `gif`, `mat`, and `aeif` models.

.. doxygengroup:: iaf
   :content-only:
