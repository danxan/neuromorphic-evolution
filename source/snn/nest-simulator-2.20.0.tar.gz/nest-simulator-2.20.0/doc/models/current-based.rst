Neuron models with current-based synapses
================================

.. doxygengroup:: psc
   :content-only:
