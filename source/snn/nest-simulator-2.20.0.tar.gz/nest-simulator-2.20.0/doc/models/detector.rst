Detector/Recorder devices
===========================


.. doxygengroup:: detector
   :content-only:
