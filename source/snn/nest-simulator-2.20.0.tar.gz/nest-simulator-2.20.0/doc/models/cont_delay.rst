Continuous delay synapse models
=======================================================

.. doxygengroup:: cont_delay
   :content-only:
