Hill-Tononi neuron model
==============================


.. doxygengroup:: ht_neuron
   :content-only:
