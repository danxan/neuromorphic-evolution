Point process (PP) neurons
===============================

.. doxygengroup:: pp
   :content-only:
