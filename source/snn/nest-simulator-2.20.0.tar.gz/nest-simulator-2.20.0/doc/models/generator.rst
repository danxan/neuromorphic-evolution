Generator type devices
================================

.. doxygengroup:: generator
   :content-only:
