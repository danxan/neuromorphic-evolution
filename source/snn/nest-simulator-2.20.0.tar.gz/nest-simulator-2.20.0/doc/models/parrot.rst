Parrot neuron
================================

.. doxygengroup:: parrot
   :content-only:
