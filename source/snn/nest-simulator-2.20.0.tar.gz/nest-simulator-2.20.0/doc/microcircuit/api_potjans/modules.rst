API reference for Microcircuit
================================

.. toctree::
   :maxdepth: 4

   helpers
   network
   network_params
