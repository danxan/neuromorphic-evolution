var x = document.getElementsByClassName("wy-side-nav-search")[0];

console.log(x);
