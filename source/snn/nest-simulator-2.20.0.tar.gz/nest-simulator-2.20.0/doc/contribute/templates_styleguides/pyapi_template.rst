PyNEST API template
=====================

.. literalinclude:: pynest_api_template.py
