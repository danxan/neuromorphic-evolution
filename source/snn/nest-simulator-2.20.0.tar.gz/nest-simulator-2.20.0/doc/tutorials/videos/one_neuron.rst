Introduction to NEST: Simulating a single neuron
==================================================


.. raw:: html

    <video width="640" controls poster="https://www.nest-simulator.org/downloads/screenshot_membranepot_video.png" >
      <source src="https://www.nest-simulator.org/downloads/DEMO_oneneuron_screencast.mp4" type="video/mp4">
    Your browser does not support the video tag.
    </video>
