Examples using Topology
========================

.. toctree::
   :maxdepth: 1

   conncomp
   conncon_sources
   conncon_targets
   connex
   gaussex
   grid_iaf
   grid_iaf_irr
   grid_iaf_oc

