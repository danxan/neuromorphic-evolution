#include <signal.h>  

int main(int argc, char const *argv[])
{
  int e( SIGUSR1 );
  return 0;
}
