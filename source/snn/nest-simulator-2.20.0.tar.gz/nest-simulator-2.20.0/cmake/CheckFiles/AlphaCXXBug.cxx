#include <cerrno>

int e( E2BIG );

int main(int argc, char const *argv[])
{
  return 0;
}
