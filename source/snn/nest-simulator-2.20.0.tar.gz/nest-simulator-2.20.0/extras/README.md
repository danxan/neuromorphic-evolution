# `extras` folder

This directory contains helper scripts for TravisCI, for checking the
code style of NEST and for running NEST in a distributed setup
(`nest_serial` and `nest_indirect`).
